  <!-- HEADER DESKTOP-->

  
<style>
  .header__navbar .header3-sub-list li a:hover {
    color: #4272d7;
    background: #008398;
}

</style>
        <header class="header-desktop3 d-none d-lg-block" style="background-color: #008398;">
            <div class="section__content section__content--p35">
                <div class="header3-wrap">
                    <div class="header__logo">
                        <a href="index.php">
                            <img src="images/logo.png" alt="CoolAdmin" style="width: 30% !important;" />
                        </a>
                    </div>
                    <div class="header__navbar">
                        <ul class="list-unstyled">
                            <li class="has-sub">
                                <a href="field_form.php" style="color:white;">
                                    Adjucator CFP
                                    <span class="bot-line"></span>
                                </a>
                                
                            </li>
                            <li>
                                <a href="oct_form.php" style="color:white;">
                                   
                                    <span class="bot-line"></span>OCT</a>
                            </li>
                            
                             <li class="has-sub">
                                <!-- <a href="#" style="color:white;">
                                    <i class="fas fa-copy"></i>
                                    <span class="bot-line"></span>Combine Data</a> -->
                                <!-- <ul class="header3-sub-list list-unstyled">
                                    <li>
                                        <a href="view_user.php">View User Data</a>
                                    </li>
                                    <li>
                                        <a href="view_subject.php">View Subject Data</a>
                                    </li>
                                    <li>
                                        <a href="#">View All Data</a>
                                    </li>
                                </ul>

 -->                            
                            
                    </div>

                    <div class="header__tool">
                       
                        
                        <div class="account-wrap">
                            <div class="log">
                                
                            <li><a href="logout.php" style="color:white;">
                                   <i class="fas fa-sign-out-alt"></i>logout</a>
                            </li>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER DESKTOP-->