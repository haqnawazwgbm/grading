  <!-- HEADER DESKTOP-->

  
<style>
  .header__navbar .header3-sub-list li a:hover {
    color: #4272d7;
    background: #008398;
}

</style>
        <header class="header-desktop3 d-none d-lg-block" style="background-color: #008398;">
            <div class="section__content section__content--p35">
                <div class="header3-wrap">
                    <div class="header__logo">
                        <a href="index.php">
                            <img src="images/logo.png" alt="CoolAdmin" style="width: 30%" />
                        </a>
                    </div>
                    <div class="header__navbar">
                        <ul class="list-unstyled">
                             <li>
                                <a href="field_form.php" style="color:white;">
                                   
                                    <span class="bot-line"></span>CFP </a>
                            </li>
                            <li>
                                <!-- <a href="index.php" style="color:white;">
                                    <i class="fas fa-shopping-basket"></i>
                                    <span class="bot-line"></span>Grading Form</a> -->
                            </li>

                             <li>
                                <a href="oct_form.php" style="color:white;">
                                    
                                    <span class="bot-line"></span>OCT </a>
                            </li>
                        </ul>
                            

                            
                            
                    </div>

                    <div class="header__tool">
                       
                        
                        <div class="account-wrap">
                            <div class="log">
                                
                            <a href="logout.php" style="color:white;">
                                   <i class="fas fa-sign-out-alt"></i> Logout</a>
                           
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER DESKTOP-->